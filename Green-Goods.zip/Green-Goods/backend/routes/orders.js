const express = require('express');
const Order = require('../models/Order');
const router = express.Router();

// Place order route
router.post('/', async (req, res) => {
    const { productId, name, email, phone } = req.body;

    try {
        const newOrder = new Order({ productId, name, email, phone });
        await newOrder.save();

        res.status(201).json({ message: 'Order placed successfully' });
    } catch (error) {
        console.error('Error placing order:', error);
        res.status(500).json({ error: 'Failed to place order. Please try again.' });
    }
});

module.exports = router;
