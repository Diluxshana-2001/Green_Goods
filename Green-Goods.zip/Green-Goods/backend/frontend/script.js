// Signup Form
document.getElementById('signupForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirm_password = document.getElementById('confirm_password').value;

    const response = await fetch('http://localhost:3000/api/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password, confirm_password })
    });

    const data = await response.text();
    alert(data);
});

//login
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            try {
                const response = await fetch('/api/users/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email, password }),
                });

                if (response.ok) {
                    alert('Login successful');
                    window.location.href = 'index.html'; // Redirect to homepage on successful login
                } else {
                    const data = await response.text();
                    alert(data); // Display error message from backend
                }
            } catch (error) {
                console.error('Error during login:', error);
                alert('Failed to login. Please try again.');
            }
        });
    } else {
        console.error('Element with ID "loginForm" not found.');
    }
});
