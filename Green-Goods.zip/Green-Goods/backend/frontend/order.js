document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productName = urlParams.get('name');
    const productPrice = urlParams.get('price');
    const productId = urlParams.get('id');
    const productQuantity = 1; 
    const orderNumber = Math.floor(Math.random() * 1000000);
    const orderDate = new Date().toLocaleDateString();

    // Set the displayed order details
    document.getElementById('product-name').textContent = `Product Name: ${productName}`;
    document.getElementById('product-quantity').textContent = `Quantity: ${productQuantity}`;
    document.getElementById('product-price').textContent = `Price: $${productPrice}`;
    document.getElementById('order-number').textContent = `Order Number: ${orderNumber}`;
    document.getElementById('order-date').textContent = `Order Date: ${orderDate}`;

    // Handle order form submission
    document.getElementById('order-form').addEventListener('submit', async (event) => {
        event.preventDefault();

        // Gather order details from the form
        const orderDetails = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            productName,
            productQuantity,
            productPrice,
            orderNumber,
            orderDate
        };

        try {
            // Send order details to the server for processing
            const response = await fetch('/api/orders', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(orderDetails)
            });

            if (response.ok) {
                alert('Order confirmed!');
                window.location.href = 'index.html'; // Redirect to homepage on successful order
            } else {
                throw new Error('Failed to confirm order. Please try again.');
            }
        } catch (error) {
            console.error('Error confirming order:', error);
            alert('Failed to confirm order. Please try again.');
        }
    });

    // Handle back button click
    document.getElementById('back-button').addEventListener('click', () => {
        window.location.href = 'index.html'; // Redirect to homepage
    });
});
