const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const User = require('./models/User');
const Order = require('./models/Order');


dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/greengoods';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'frontend')));

mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Signup route
app.post('/api/signup', async (req, res) => {
    const { email, password } = req.body;
    const existingUser = await User.findOne({ email });

    if (existingUser) {
        return res.status(400).json({ error: 'User already exists with this email' });
    }

    const newUser = new User({ email, password });
    await newUser.save();
    res.status(201).json({ message: 'Signup successful' });
});

// Login route
app.post('/api/users/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }

    try {
        const user = await User.findOne({ email, password });

        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Redirect to index.html on successful login
        res.status(200).json({ message: 'Login successful' });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ error: 'Server error' });
    }
});


// Order route
app.post('/api/orders', async (req, res) => {
    const { name, email, phone, productName, productQuantity, productPrice, orderNumber, orderDate } = req.body;
    
    try {
        // Create a new Order document
        const newOrder = new Order({
            name,
            email,
            phone,
            productName,
            productQuantity,
            productPrice,
            orderNumber,
            orderDate
        });

        // Save the order to MongoDB
        await newOrder.save();

        res.status(200).json({ message: 'Order confirmed!' });
    } catch (error) {
        console.error('Error confirming order:', error);
        res.status(500).json({ error: 'Failed to confirm order. Please try again.' });
    }
});


// Route to fetch all products (example)
app.get('/api/products', async (req, res) => {
    const products = await Product.find();
    res.status(200).json(products);
});

// Serve index.html for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'index.html'), (err) => {
        if (err) {
            console.error('Error serving index.html:', err);
            res.status(500).send('Internal Server Error');
        }
    });
});



app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
